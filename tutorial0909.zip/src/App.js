import React from 'react'
import NavbarComponent from './components/NavbarComponent'
import SliderComponent from './components/SliderComponent'

import CardComponent from './components/CardComponent'

function App() {
  return (
    <div>
      <NavbarComponent/>
      <SliderComponent/>
      <CardComponent/>
    </div>
  )
}

export default App
